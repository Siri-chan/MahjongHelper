This set of icons includes the flower and season tiles which were missing in the first release of my mahjong icon pack.

You are free to use and modify these icons for any purpose (personal and commercial),
under the condition that you provide a link to http://www.martinpersson.org.

Regards,

Martin Persson
Website: http://www.martinpersson.org
Email: contact@martinpersson.org